package br.com.caelum.financas.teste;

import javax.persistence.EntityManager;

import br.com.caelum.financas.modelo.Conta;
import br.com.caelum.financas.util.JPAUtil;


public class TesteBuscaConta {
	
	public static void main(String[] args) {
		EntityManager em = new JPAUtil().getEntityManager();
		em.getTransaction().begin();
		
		/*
			buscar uma conta (passa o lugar que quer buscar e o id, � importante que o id seja do 
			mesmo tipo que o que est� na classe Conta, l� no caso esta Integer, ent�o est� certo 
			passar o 1
		*/
		Conta conta = em.find(Conta.class, 1);
		
		/*
		 	estado managed = dados sao automaticamente sincronizados com o banco de dados
			quando eu fa�o esse find, entra em estado Managed ent�o qualquer altera��o que eu fa�o,
			ele da um update automaticamente no banco ex:
			
		*/
		conta.setTitular("Jo�o");
		
		//se eu rodar um:
		conta.setAgencia("123");
		
		/*
			ele nao vai dar um update, porque ele verifica no banco que esse j� � o n�mero da ag�ncia,
			ou seja, nao da um update, porque a conta da memoria � igual a conta do BD
		*/
		
		System.out.println(conta.getTitular());
		
		/*
		    Com o JPA, o objetivo � sempre trazer os objetos para o estado Managed, 
			j� que assim eles ser�o gerenciados e automaticamente sincronizados com o banco.
		*/
		
		em.getTransaction().commit();
		
		//a partir do momento que fechamos (ou limpamos "clear()"), o estado n�o � mais managed
		em.close();
		
		
		EntityManager em2 = new JPAUtil().getEntityManager();
		em2.getTransaction().begin();
		
		/*
			detached, porque essa conta n�o � mais gerenciada pelo JPA, mas ela j� foi um dia 
			h� uma representa��o dela no banco, mas a sincroniza��o autom�tica dela n�o est� ativada
		*/
		conta.setTitular("Leonardo");
		
		/*	
			fun��o do merge � transformar em managed de novo e quando se torna managed
			automaticamente ocorre a sincroniza��o
		*/
		em2.merge(conta);
		
		
		em2.close();
		
		
	}

}
